# Samsung PRISM XR Hackathon Challenge 2026
## Track 1: Synthetic Eye Movement & Virtual Camera Rendering

**Team Submission Package**  
**Track:** Track 1 – Synthetic Eye Movement & Virtual Camera Rendering  
**Organized by:** Samsung R&D Institute India, Bangalore (SRI-B)

---

## 1. Official GitHub Submission Checklist Mapping

This repository fulfills 100% of the Samsung PRISM XR Hackathon submission requirements:

| Checklist Item | Repository Deliverable | Verification Status |
| :--- | :--- | :--- |
| **☑ Submission Package** | [`Samsung_PRISM_XR_Track1_Submission.zip`](Samsung_PRISM_XR_Track1_Submission.zip) (24.03 MB) | Complete & Validated |
| **☑ Source Code** | [`wrapper/eyes.py`](wrapper/eyes.py), [`wrapper/dataset_factory.py`](wrapper/dataset_factory.py), `ocurender-xr/` | 5/5 Direction Tests Passed |
| **☑ Presentation** | [`VIT_OcuRenderXR_Submission.pptx`](VIT_OcuRenderXR_Submission.pptx) | Complete 9-Slide Deck |
| **☑ Video** | [`videos/input_left.mp4`](videos/input_left.mp4), [`videos/input_right.mp4`](videos/input_right.mp4), [`videos/input_generate_motion.mp4`](videos/input_generate_motion.mp4) | All 3 MP4s (<15s each) |
| **☑ AI Disclosure** | [`AI_DISCLOSURE.md`](AI_DISCLOSURE.md) | Full Disclosure Documented |
| **☑ README** | [`README.md`](README.md) | Exhaustive Documentation |
| **☑ APK/SDK** | Python Evaluation SDK (`wrapper/`) & Real-Time WebXR Engine (`ocurender-xr/`) | Dual-Engine Architecture |

---

## 2. Executive Summary

This project delivers a production-grade, mathematically calibrated 3D synthetic eye movement and virtual camera rendering system built on Blender 4.2 LTS. The system provides high-fidelity, anatomically grounded eye gaze redirection and projective camera geometry with ground truth annotations conforming to the Samsung PRISM automated evaluation specification.

### Key Highlights
- **100% Deterministic Kinematics**: Bilateral ocular pose constraints (`DAMPED_TRACK`) bound to an anatomical MakeHuman (CC0) base mesh and armature rig, tracking a calibrated 35 cm fixation target.
- **Sub-Pixel Ground Truth Precision**: Automatic extraction of 3D eye rotation matrices ($3 \times 3$), projected 2D pupil centers ($[x, y]$ in pixel space), and camera intrinsic projection matrix ($K$).
- **Dual Execution Engine**:
  - **Native Blender Mode**: Direct scene manipulation for high performance.
  - **External Python CLI Proxy**: Seamless execution from any standard Python 3.10+ shell via automated headless Blender subprocess management.
- **5/5 Direction Test Pass Rate**: Full mathematical verification across all cardinal directions (Reset, Right, Left, Up, Down).

---

## 2. Directory Structure

```
team_name/
├── scene.blend                 # Calibrated 3D character, eye rig, lighting, and camera
├── wrapper/
│   ├── __init__.py             # Package initializer exposing controller interface
│   └── eyes.py                 # Core evaluation API (move, reset, render)
├── renders/                    # 10 Clockwise benchmark frames & test renders
│   ├── frame_000.png           # theta = 0.0°   (Up: h=0.000, v=1.000)
│   ├── frame_001.png           # theta = 36.0°  (Up-Right)
│   ├── frame_002.png           # theta = 72.0°  (Right-Up)
│   ├── frame_003.png           # theta = 108.0° (Right-Down)
│   ├── frame_004.png           # theta = 144.0° (Down-Right)
│   ├── frame_005.png           # theta = 180.0° (Down: h=0.000, v=-1.000)
│   ├── frame_006.png           # theta = 216.0° (Down-Left)
│   ├── frame_007.png           # theta = 252.0° (Left-Down)
│   ├── frame_008.png           # theta = 288.0° (Left-Up)
│   └── frame_009.png           # theta = 324.0° (Up-Left)
├── metadata.json               # Frame-by-frame ground truth annotations
└── README.md                   # Setup, execution guide, and mathematical documentation
```

---

## 3. System Requirements & Installation

### Requirements
- **Blender:** 4.2 LTS (recommended: 4.2.16 LTS or any Blender 4.x)
- **Python:** 3.10, 3.11, or 3.12 (standard Python or Blender's bundled Python)
- **OS:** Windows 10/11, Ubuntu 22.04+, or macOS 13+

### Environment Setup
Ensure `blender` is in your system `PATH`:
```bash
# Verify Blender accessibility
blender --version
```
*Note: If Blender is installed in a non-standard location, set the `BLENDER_PATH` environment variable pointing to the `blender` executable.*

---

## 4. Evaluator Quick Start

### Option A: Run Full Automated Benchmark via Blender (Recommended)
From the submission root directory:
```bash
blender scene.blend -b -P wrapper/eyes.py
```
This executes:
1. 5/5 direction verification unit tests (Reset, Right, Left, Up, Down).
2. 10 clockwise renders ($\theta_k = 2\pi k / 10$) saved to `renders/frame_000.png` through `frame_009.png`.
3. Validation and generation of `metadata.json`.

### Option B: Run via Standard Python Terminal
```bash
python wrapper/eyes.py
```
The script auto-detects standard Python and launches headless Blender subprocesses transparently.

### Option C: Interactive Python API Usage
```python
from wrapper.eyes import eyes

# 1. Reset eyes to center primary gaze
eyes.reset()

# 2. Move gaze: h (horizontal) and v (vertical) in [-1.0, 1.0]
#    h: +1.0 = Right, -1.0 = Left
#    v: +1.0 = Up,    -1.0 = Down
eyes.move(h=1.0, v=0.0)

# 3. Render 1024x1024 PNG frame and retrieve ground truth metadata
meta = eyes.render("renders/my_test_frame.png")

print("2D Left Pupil [x, y]:", meta["pupil_center_2D_L"])
print("2D Right Pupil [x, y]:", meta["pupil_center_2D_R"])
print("3D Left Eye Rotation Matrix:\n", meta["eye_rotation_L"])
print("Camera Matrix K:\n", meta["camera_matrix"])
```

---

## 5. Mathematical & Architectural Specification

### 5.1 Ocular Geometry & Calibration
- **Facial Base Mesh:** CC0 MakeHuman anatomical base topology.
- **Eyeball Radius:** $R = 12.5\text{ mm}$ (anatomical adult human standard).
- **Socket Alignment:** Eyeball centers anchored at $(X=\pm 0.0308, Y=-0.1245, Z=1.5462)\text{ m}$.
- **Procedural Cornea/Iris BSDF:** Procedural spherical gradient mapping defining pupil ($r \le 3.4\text{ mm}$), striated blue iris ($r \le 7.5\text{ mm}$), limbal dark ring ($r \le 8.6\text{ mm}$), and high-diffuse ivory sclera ($r > 9.4\text{ mm}$), finished with corneal clearcoat ($IOR = 1.336$, roughness $0.04$).

### 5.2 Kinematics & Fixation Tracking
- **Fixation Target:** Virtual target positioned 35 cm forward from eye midpoint at $(0.0, -0.4745, 1.5462)\text{ m}$.
- **Tracking Constraints:** `DAMPED_TRACK` constraints on pose bones `eye.L` and `eye.R` targeting the fixation empty along the local longitudinal axis (`TRACK_Y`).
- **Gaze Scales:**
  - Horizontal ($H\_SCALE = 0.075\text{ m}$): Yields $\approx \pm 12^\circ$ comfortable saccadic excursion without eyelid occlusion.
  - Vertical ($V\_SCALE = 0.055\text{ m}$): Yields $\approx \pm 9^\circ$ vertical elevation/depression.

### 5.3 Projective Geometry & Camera Intrinsics
- **Camera Sensor:** $36.0\text{ mm} \times 36.0\text{ mm}$ square full-frame sensor.
- **Focal Length:** $72.0\text{ mm}$ portrait focal length.
- **Resolution:** $1024 \times 1024$ pixels (1:1 pixel aspect ratio).
- **Camera Position:** 40 cm forward from eye midpoint at $(0.0, -0.5245, 1.5462)\text{ m}$ facing $+Y$ (`rotation_euler = (90°, 0°, 0°)`).
- **Intrinsic Matrix ($K$):**
  $$f_x = f_y = 72.0 \times \frac{1024}{36.0} = 2048.0\text{ px}$$
  $$c_x = c_y = \frac{1024}{2} = 512.0\text{ px}$$
  $$K = \begin{bmatrix} 2048.0 & 0.0 & 512.0 \\ 0.0 & 2048.0 & 512.0 \\ 0.0 & 0.0 & 1.0 \end{bmatrix}$$

- **2D Projected Pupil Centers:**
  Computed via projective ray projection `bpy_extras.object_utils.world_to_camera_view` of the anterior corneal vertex $(0.0, R, 0.0)$ transformed to world space:
  $$\text{pixel\_x} = u \times 1024$$
  $$\text{pixel\_y} = (1.0 - v) \times 1024$$

---

## 6. Verification & Evaluation Results

### Direction Verification Matrix (5/5 PASS)
| Test Case | $(h, v)$ | Pupil Left Delta $(\Delta x, \Delta y)$ | Pupil Right Delta $(\Delta x, \Delta y)$ | Expected Direction | Status |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Reset** | $(0.0, 0.0)$ | Baseline $(669.4, 527.0)\text{ px}$ | Baseline $(354.6, 527.0)\text{ px}$ | Centered ($512\text{ px}$ midpoint) | **PASS** |
| **Right** | $(+1.0, 0.0)$ | $(+18.1, -0.1)\text{ px}$ | $(+18.1, +0.1)\text{ px}$ | Positive $X$ Shift | **PASS** |
| **Left** | $(-1.0, 0.0)$ | $(-18.1, +0.1)\text{ px}$ | $(-18.1, -0.1)\text{ px}$ | Negative $X$ Shift | **PASS** |
| **Up** | $(0.0, +1.0)$ | $(+0.4, -15.1)\text{ px}$ | $(-0.4, -15.1)\text{ px}$ | Negative $Y$ Shift (Screen Up) | **PASS** |
| **Down** | $(0.0, -1.0)$ | $(-0.4, +13.8)\text{ px}$ | $(+0.4, +13.8)\text{ px}$ | Positive $Y$ Shift (Screen Down)| **PASS** |

### Clockwise Gaze Trajectory ($\theta_k = 2\pi k / 10$)
The 10 frames sample the unit circle clockwise starting from 12 o'clock ($\theta_0 = 0$, Up):
- Frame 0: $h = 0.000, v = +1.000$ (Top)
- Frame 1: $h = +0.588, v = +0.809$ (Top-Right)
- Frame 2: $h = +0.951, v = +0.309$ (Right-Top)
- Frame 3: $h = +0.951, v = -0.309$ (Right-Bottom)
- Frame 4: $h = +0.588, v = -0.809$ (Bottom-Right)
- Frame 5: $h = 0.000, v = -1.000$ (Bottom)
- Frame 6: $h = -0.588, v = -0.809$ (Bottom-Left)
- Frame 7: $h = -0.951, v = -0.309$ (Left-Bottom)
- Frame 8: $h = -0.951, v = +0.309$ (Left-Top)
- Frame 9: $h = -0.588, v = +0.809$ (Top-Left)

All frames rendered at $1024 \times 1024$ RGBA PNG and logged into `metadata.json`.

---

## 7. Downstream XR Usage Companion
To demonstrate the utility of this synthetic data generation pipeline in downstream XR applications (Apple Vision Pro, Meta Quest, and Samsung XR headsets), an interactive companion application is available in the project repository demonstrating:
- Real-time gaze-contingent foveated rendering simulation.
- Low-latency telepresence avatar driving.
- Mathematical gaze intersection and attentional heatmap projection.

---

## 8. Compliance Checklist
- [x] `scene.blend` exists and opens cleanly in standard Blender 4.2 LTS.
- [x] `wrapper/eyes.py` exposes `move(h, v)`, `reset()`, and `render(filepath)`.
- [x] Dual-mode CLI execution verified (runs via Blender `-P` and standalone `python`).
- [x] 10 clockwise renders at $1024 \times 1024$ PNG stored in `renders/`.
- [x] `metadata.json` conforms to schema with camera matrix, 3D rotations, and 2D pupil centers.
- [x] 5/5 direction tests pass with sub-pixel verification.
- [x] Fully self-contained submission bundle conforming to Samsung PRISM specifications.
